#include "natcn.h"
#include<stdbool.h>

typedef struct pos
{
    int x;
    int y;
} Pos;

Pos a[125005][2];
bool exist[125005] = {0};


void init(int map[][505], int n, int m) {
    // Write your code here
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            int num = map[i][j];
            if(exist[num]) {
                a[num][1].x = i;
                a[num][1].y = j;
            }
            else {
                exist[num] = true;
                a[num][0].x = i;
                a[num][0].y = j;
            }
        }
    }
}

int *get_position(int value, int order) {
    // Do not modify the following line
    int *position = (int *)malloc(2 * sizeof(int));

    // Write your code here
    /*
        Heap memory and pointer, here it is! You don't need to understand it now, just see it as an integer array 'int position[2];'. 
        You can modify the value in this array, the effect will be passed out of this function.
        Let's say:
            position[0] = 1;
            position[1] = 2;
        This stands for a position (1, 2).
        
        @advanced* (you may ignore this part)
            - What would happen if you just use 'int position[2];'?
    */
    position[0] = a[value][order].x;
    position[1] = a[value][order].y;
    // Do not modify the following line
    return position;
}

bool walk(int map[][505], int n, int m, int x, int y, int dx, int dy) {
    // Write your code here
    int flag = true;
    int i = x + dx, j = y + dy;
    while(i >= 0 && i < n && j >= 0 && j < m) {
        if(map[i][j] != 0) {
            flag = false;
            break;
        }
        i += dx;
        j += dy;
    }
    return flag;
}
