#pragma once
#define MAX_SIZE 101
void  matrix_multiply(int A[][MAX_SIZE], int B[][MAX_SIZE], int C[][MAX_SIZE], int m, int n, int p);