#include "sudoku.h"
// 检查某一行是否有效
#include <stdio.h>

#define SIZE 9

// 检查某一行是否有效
int check_row(int grid[SIZE][SIZE], int row) {
    int exist[SIZE] = {0};
    for(int j = 0; j < SIZE; j++) {
        if(exist[grid[row][j] - 1] == 0) exist[grid[row][j] - 1] = 1;
        else {
            return 0;
        }
    }
    return 1;
}

// 检查某一列是否有效
int check_column(int grid[SIZE][SIZE], int col) {
    int exist[SIZE] = {0};
    for(int i = 0; i < SIZE; i++) {
        if(exist[grid[i][col] - 1] == 0) exist[grid[i][col] - 1] = 1;
        else {
            return 0;
        }
    }
    return 1;
}

// 检查3x3小方格是否有效
int check_block(int grid[SIZE][SIZE], int start_row, int start_col) {
    int exist[SIZE] = {0};
    for(int i = start_row; i < start_row + 3; i++) {
        for(int j = start_col; j < start_col + 3; j++) {
            if(exist[grid[i][j] - 1] == 0) exist[grid[i][j] - 1] = 1;
            else {
                return 0;
            }
        }
    }
    return 1;
}
